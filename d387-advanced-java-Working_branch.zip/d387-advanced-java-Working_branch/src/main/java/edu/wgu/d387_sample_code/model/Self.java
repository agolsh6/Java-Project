package edu.wgu.d387_sample_code.model;

public class Self {

    private String ref;

    public String getRef() {
        return ref;
    }

    public void setRef(String ref) {
        this.ref = ref;
    }
}
